from app import app
import urllib
import os

# secret key for user session
app.secret_key = "ITSASECRET"

#setting up mail
app.config['MAIL_SERVER']='smtp.gmail.com' #mail server
app.config['MAIL_PORT'] = 465 #mail port
app.config['MAIL_USERNAME'] = 'raissadevy@gmail.com' #email
app.config['MAIL_PASSWORD'] = 'r41ss4d3vY[' #os.environ['MAIL_PASSWORD'] #password
app.config['MAIL_USE_TLS'] = True #security type
app.config['MAIL_USE_SSL'] = True #security type

#database connection parameters
connection_params = {
    'user': '',
    'password': '',
    'host': 'localhost',
    'port': 27017,
    'namespace': '',
}
