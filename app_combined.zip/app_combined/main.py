import numpy as np
import pandas as pd
from surprise import KNNBasic
from surprise import Reader, SVD, Dataset
from flask import Flask, render_template, request

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Content based 
def create_sim():
    data = pd.read_csv('data_coffee.csv')
    cv = CountVectorizer(
      tokenizer = lambda x:x.split(',')
    )
    count_matrix = cv.fit_transform(data['all_attr'])
    count_matrix.toarray()
    sim = cosine_similarity(count_matrix)
    return data,sim

def rcmd(cof):
    cof = cof.lower()
    try:
        data.head()
        sim.shape
    except:
        data, sim = create_sim()

    if cof not in data['product'].unique():
        return('This product is not in our database.\nPlease check if you spelled it correct.')
    else:
        i = data.loc[data['product']==cof].index[0]
        recommend_list = list(enumerate(sim[i]))
        recommend_list = sorted(recommend_list, key = lambda x:x[1] ,reverse=True)
        recommend_list = recommend_list[1:11]
        l = []
        for i in range(len(recommend_list)):
            a = recommend_list[i][0]
            l.append(data['product'][a])
        return l

# Collaborative filtering
class RecommenderSystem:
    def __init__ (self):
        self.df = pd.read_csv("df_recommender_data.csv")
        self.all_product = self.df['product'].unique()
        self.model = None
    
    def fit(self):
        data = Dataset.load_from_df(self.df, Reader())
        trainset = data.build_full_trainset()    
        self.model = KNNBasic()
        self.model.fit(trainset)
    
    def historical_purchase (self, cust_id):
        tried = self.df[self.df.customer_id == cust_id]['product']
        qty = self.df[self.df.customer_id == cust_id]['quantity_total']
        df_tried = pd.DataFrame({"product" : tried, "historical_purchase": qty})
        return df_tried.head(10)
        
    def recommend(self, cust_id, top=10):
        tried = self.df[self.df.customer_id == cust_id]['product']
        not_tried = [i for i in self.all_product if i not in tried]
        score = [self.model.predict(cust_id, i).est for i in not_tried]

        result = pd.DataFrame({"product" : not_tried, "pred_score": score})
        result.sort_values("pred_score", ascending=False, inplace=True)

        rec_product = [i for i in result['product'].head(top)]
        return rec_product


app = Flask(__name__)

@app.route("/")
def home():
    return render_template('home.html')

@app.route("/recommend")
def recommend():
    coffee = request.args.get('coffee')
    r = rcmd(coffee)
    coffee = coffee.capitalize()
    if type(r)==type('string'):
        return render_template('recommend.html',coffee=coffee,r=r,t='s')
    else:
        return render_template('recommend.html',coffee=coffee,r=r,t='l')


@app.route("/recom_cf")
def recom_cf():
    recsys = RecommenderSystem()
    recsys.fit()
    customerrr_id = request.args.get('cust_id')
    # cust_name = 
    recommendation_list = recsys.recommend(cust_id = customerrr_id)

    return render_template('recom_cf.html',cust_id=customerrr_id,recommendation_list=recommendation_list)

if __name__ == '__main__':
    app.run()
